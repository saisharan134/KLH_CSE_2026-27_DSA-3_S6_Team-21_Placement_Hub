package com.placementhub.api;

import com.placementhub.CorsFilter;
import com.placementhub.dao.StudentDAO;
import com.placementhub.model.Student;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class StudentAPI {

    private final StudentDAO studentDAO = new StudentDAO();

    public void registerRoutes(HttpServer server) {

        var loginContext = server.createContext(
                "/api/students/login",
                this::login
        );

        loginContext.getFilters().add(
                new CorsFilter()
        );

        var registerContext = server.createContext(
                "/api/students/register",
                this::register
        );

        registerContext.getFilters().add(
                new CorsFilter()
        );
    }

    // =====================================================
    // LOGIN
    // =====================================================

    private void login(HttpExchange exchange)
            throws IOException {

        if (!exchange.getRequestMethod()
                .equalsIgnoreCase("POST")) {

            send(
                    exchange,
                    405,
                    "{\"error\":\"POST required\"}"
            );

            return;
        }

        String body = new String(
                exchange.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8
        );

        String email = getValue(body, "email");
        String password = getValue(body, "password");

        Student student =
                studentDAO.login(email, password);

        if (student == null) {

            send(
                    exchange,
                    401,
                    "{\"error\":\"Invalid email or password\"}"
            );

            return;
        }

        String json =
                "{"
                + "\"studentId\":"
                + student.getStudentId()
                + ","
                + "\"name\":\""
                + escape(student.getName())
                + "\","
                + "\"email\":\""
                + escape(student.getEmail())
                + "\","
                + "\"branch\":\""
                + escape(student.getBranch())
                + "\","
                + "\"cgpa\":"
                + student.getCgpa()
                + ","
                + "\"backlogs\":"
                + student.getBacklogs()
                + ","
                + "\"skills\":\""
                + escape(student.getSkills())
                + "\","
                + "\"graduationYear\":"
                + student.getGraduationYear()
                + "}";

        send(exchange, 200, json);
    }

    // =====================================================
    // REGISTER
    // =====================================================

    private void register(HttpExchange exchange)
            throws IOException {

        if (!exchange.getRequestMethod()
                .equalsIgnoreCase("POST")) {

            send(
                    exchange,
                    405,
                    "{\"error\":\"POST required\"}"
            );

            return;
        }

        String body = new String(
                exchange.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8
        );

        try {

            Student student = new Student(
                    getValue(body, "name"),
                    getValue(body, "email"),
                    getValue(body, "password"),
                    getValue(body, "phone"),
                    getValue(body, "branch"),

                    Double.parseDouble(
                            getValue(body, "cgpa")
                    ),

                    Integer.parseInt(
                            getValue(body, "backlogs")
                    ),

                    getValue(body, "skills"),

                    Integer.parseInt(
                            getValue(body, "graduationYear")
                    )
            );

            boolean success =
                    studentDAO.register(student);

            if (success) {

                send(
                        exchange,
                        201,
                        "{\"message\":\"Registration successful\"}"
                );

            } else {

                send(
                        exchange,
                        400,
                        "{\"error\":\"Registration failed. Email may already exist.\"}"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            send(
                    exchange,
                    400,
                    "{\"error\":\"Invalid student data\"}"
            );
        }
    }

    // =====================================================
    // JSON VALUE
    // =====================================================

    private String getValue(
            String json,
            String key) {

        String search = "\"" + key + "\"";

        int keyIndex =
                json.indexOf(search);

        if (keyIndex == -1) {
            return "";
        }

        int colon =
                json.indexOf(":", keyIndex);

        if (colon == -1) {
            return "";
        }

        int start = colon + 1;

        while (
                start < json.length()
                && Character.isWhitespace(
                        json.charAt(start))
        ) {
            start++;
        }

        if (
                start < json.length()
                && json.charAt(start) == '"'
        ) {

            start++;

            int end =
                    json.indexOf('"', start);

            if (end == -1) {
                return "";
            }

            return json.substring(
                    start,
                    end
            );
        }

        int end =
                json.indexOf(",", start);

        if (end == -1) {
            end = json.indexOf("}", start);
        }

        if (end == -1) {
            return "";
        }

        return json.substring(
                start,
                end
        ).trim();
    }

    // =====================================================
    // ESCAPE JSON
    // =====================================================

    private String escape(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }

    // =====================================================
    // SEND RESPONSE
    // =====================================================

    private void send(
            HttpExchange exchange,
            int status,
            String response)
            throws IOException {

        exchange.getResponseHeaders().set(
                "Content-Type",
                "application/json"
        );

        byte[] data =
                response.getBytes(
                        StandardCharsets.UTF_8
                );

        exchange.sendResponseHeaders(
                status,
                data.length
        );

        try (
                OutputStream output =
                        exchange.getResponseBody()
        ) {

            output.write(data);
        }
    }
}