package com.placementhub.api;

import com.placementhub.CorsFilter;
import com.placementhub.dao.CompanyDAO;
import com.placementhub.model.Company;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class CompanyAPI {

    private final CompanyDAO companyDAO =
            new CompanyDAO();

    public void registerRoutes(
            HttpServer server) {

        var companyContext =
                server.createContext(
                        "/api/companies",
                        this::getCompanies
                );

        companyContext.getFilters().add(
                new CorsFilter()
        );
    }

    // =====================================================
    // GET ALL COMPANIES
    // =====================================================

    private void getCompanies(
            HttpExchange exchange)
            throws IOException {

        if (!exchange.getRequestMethod()
                .equalsIgnoreCase("GET")) {

            send(
                    exchange,
                    405,
                    "{\"error\":\"GET required\"}"
            );

            return;
        }

        List<Company> companies =
                companyDAO.getAllCompanies();

        StringBuilder json =
                new StringBuilder("[");

        for (int i = 0;
             i < companies.size();
             i++) {

            Company company =
                    companies.get(i);

            json.append("{")

                    .append("\"companyId\":")
                    .append(
                            company.getCompanyId()
                    )
                    .append(",")

                    .append("\"companyName\":\"")
                    .append(
                            escape(
                                    company.getCompanyName()
                            )
                    )
                    .append("\",")

                    .append("\"location\":\"")
                    .append(
                            escape(
                                    company.getLocation()
                            )
                    )
                    .append("\",")

                    .append("\"website\":\"")
                    .append(
                            escape(
                                    company.getWebsite()
                            )
                    )
                    .append("\",")

                    .append("\"description\":\"")
                    .append(
                            escape(
                                    company.getDescription()
                            )
                    )
                    .append("\"")

                    .append("}");

            if (i < companies.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        send(
                exchange,
                200,
                json.toString()
        );
    }

    private String escape(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }

    private void send(
            HttpExchange exchange,
            int status,
            String response)
            throws IOException {

        exchange.getResponseHeaders().set(
                "Content-Type",
                "application/json"
        );

        byte[] data =
                response.getBytes(
                        StandardCharsets.UTF_8
                );

        exchange.sendResponseHeaders(
                status,
                data.length
        );

        try (
                OutputStream output =
                        exchange.getResponseBody()
        ) {

            output.write(data);
        }
    }
}