package com.placementhub.api;

import com.placementhub.CorsFilter;
import com.placementhub.DBConnection;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ApplicationAPI {

    public void registerRoutes(
            HttpServer server) {

        var applicationContext =
                server.createContext(
                        "/api/applications",
                        this::handle
                );

        applicationContext.getFilters().add(
                new CorsFilter()
        );
    }

    // =====================================================
    // HANDLE APPLICATION REQUEST
    // =====================================================

    private void handle(
            HttpExchange exchange)
            throws IOException {

        String method =
                exchange.getRequestMethod();

        if (method.equalsIgnoreCase("POST")) {

            apply(exchange);

        } else if (
                method.equalsIgnoreCase("GET")
        ) {

            getApplications(exchange);

        } else {

            send(
                    exchange,
                    405,
                    "{\"error\":\"GET or POST required\"}"
            );
        }
    }

    // =====================================================
    // APPLY FOR JOB
    // =====================================================

    private void apply(
            HttpExchange exchange)
            throws IOException {

        String body = new String(
                exchange.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8
        );

        try {

            int studentId =
                    Integer.parseInt(
                            getValue(
                                    body,
                                    "studentId"
                            )
                    );

            int jobId =
                    Integer.parseInt(
                            getValue(
                                    body,
                                    "jobId"
                            )
                    );

            String checkSQL = """
                    SELECT application_id
                    FROM applications
                    WHERE student_id = ?
                    AND job_id = ?
                    """;

            try (
                    Connection con =
                            DBConnection.getConnection();

                    PreparedStatement check =
                            con.prepareStatement(
                                    checkSQL
                            )
            ) {

                check.setInt(
                        1,
                        studentId
                );

                check.setInt(
                        2,
                        jobId
                );

                ResultSet rs =
                        check.executeQuery();

                if (rs.next()) {

                    send(
                            exchange,
                            409,
                            "{\"error\":\"You have already applied for this job.\"}"
                    );

                    return;
                }
            }

            String insertSQL = """
                    INSERT INTO applications
                    (
                        student_id,
                        job_id,
                        application_date,
                        status
                    )
                    VALUES (?, ?, CURDATE(), 'Applied')
                    """;

            try (
                    Connection con =
                            DBConnection.getConnection();

                    PreparedStatement insert =
                            con.prepareStatement(
                                    insertSQL
                            )
            ) {

                insert.setInt(
                        1,
                        studentId
                );

                insert.setInt(
                        2,
                        jobId
                );

                int result =
                        insert.executeUpdate();

                if (result > 0) {

                    send(
                            exchange,
                            201,
                            "{\"message\":\"Application submitted successfully\"}"
                    );

                } else {

                    send(
                            exchange,
                            400,
                            "{\"error\":\"Application failed\"}"
                    );
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            send(
                    exchange,
                    400,
                    "{\"error\":\"Invalid application data\"}"
            );
        }
    }

    // =====================================================
    // GET STUDENT APPLICATIONS
    // =====================================================

    private void getApplications(
            HttpExchange exchange)
            throws IOException {

        String query =
                exchange.getRequestURI()
                        .getQuery();

        String studentIdText =
                getQueryParameter(
                        query,
                        "studentId"
                );

        if (studentIdText == null) {

            send(
                    exchange,
                    400,
                    "{\"error\":\"studentId required\"}"
            );

            return;
        }

        int studentId;

        try {

            studentId =
                    Integer.parseInt(
                            studentIdText
                    );

        } catch (NumberFormatException e) {

            send(
                    exchange,
                    400,
                    "{\"error\":\"Invalid studentId\"}"
            );

            return;
        }

        String sql = """
                SELECT
                    a.application_id,
                    a.student_id,
                    a.job_id,
                    a.application_date,
                    a.status,
                    j.job_role,
                    c.company_name

                FROM applications a

                JOIN jobs j
                ON a.job_id = j.job_id

                JOIN companies c
                ON j.company_id = c.company_id

                WHERE a.student_id = ?

                ORDER BY a.application_id DESC
                """;

        StringBuilder json =
                new StringBuilder("[");

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(
                    1,
                    studentId
            );

            ResultSet rs =
                    ps.executeQuery();

            boolean first = true;

            while (rs.next()) {

                if (!first) {
                    json.append(",");
                }

                first = false;

                json.append("{")

                        .append("\"applicationId\":")
                        .append(
                                rs.getInt(
                                        "application_id"
                                )
                        )

                        .append(",")

                        .append("\"studentId\":")
                        .append(
                                rs.getInt(
                                        "student_id"
                                )
                        )

                        .append(",")

                        .append("\"jobId\":")
                        .append(
                                rs.getInt(
                                        "job_id"
                                )
                        )

                        .append(",")

                        .append("\"jobRole\":\"")
                        .append(
                                escape(
                                        rs.getString(
                                                "job_role"
                                        )
                                )
                        )
                        .append("\",")

                        .append("\"companyName\":\"")
                        .append(
                                escape(
                                        rs.getString(
                                                "company_name"
                                        )
                                )
                        )
                        .append("\",")

                        .append("\"applicationDate\":\"")
                        .append(
                                escape(
                                        String.valueOf(
                                                rs.getDate(
                                                        "application_date"
                                                )
                                        )
                                )
                        )
                        .append("\",")

                        .append("\"status\":\"")
                        .append(
                                escape(
                                        rs.getString(
                                                "status"
                                        )
                                )
                        )
                        .append("\"")

                        .append("}");
            }

        } catch (Exception e) {

            e.printStackTrace();

            send(
                    exchange,
                    500,
                    "{\"error\":\"Database error\"}"
            );

            return;
        }

        json.append("]");

        send(
                exchange,
                200,
                json.toString()
        );
    }

    // =====================================================
    // JSON VALUE
    // =====================================================

    private String getValue(
            String json,
            String key) {

        String search =
                "\"" + key + "\"";

        int keyIndex =
                json.indexOf(search);

        if (keyIndex == -1) {
            return "";
        }

        int colon =
                json.indexOf(
                        ":",
                        keyIndex
                );

        if (colon == -1) {
            return "";
        }

        int start =
                colon + 1;

        while (
                start < json.length()
                && Character.isWhitespace(
                        json.charAt(start))
        ) {

            start++;
        }

        if (
                start < json.length()
                && json.charAt(start) == '"'
        ) {

            start++;

            int end =
                    json.indexOf(
                            '"',
                            start
                    );

            if (end == -1) {
                return "";
            }

            return json.substring(
                    start,
                    end
            );
        }

        int end =
                json.indexOf(
                        ",",
                        start
                );

        if (end == -1) {

            end =
                    json.indexOf(
                            "}",
                            start
                    );
        }

        if (end == -1) {
            return "";
        }

        return json.substring(
                start,
                end
        ).trim();
    }

    // =====================================================
    // QUERY PARAMETER
    // =====================================================

    private String getQueryParameter(
            String query,
            String name) {

        if (query == null) {
            return null;
        }

        for (String part :
                query.split("&")) {

            String[] pair =
                    part.split(
                            "=",
                            2
                    );

            if (
                    pair.length == 2
                    && pair[0].equals(name)
            ) {

                return pair[1];
            }
        }

        return null;
    }

    // =====================================================
    // ESCAPE JSON
    // =====================================================

    private String escape(
            String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }

    // =====================================================
    // SEND RESPONSE
    // =====================================================

    private void send(
            HttpExchange exchange,
            int status,
            String response)
            throws IOException {

        exchange.getResponseHeaders().set(
                "Content-Type",
                "application/json"
        );

        byte[] data =
                response.getBytes(
                        StandardCharsets.UTF_8
                );

        exchange.sendResponseHeaders(
                status,
                data.length
        );

        try (
                OutputStream output =
                        exchange.getResponseBody()
        ) {

            output.write(data);
        }
    }
}