package com.placementhub.api;

import com.placementhub.CorsFilter;
import com.placementhub.dao.JobDAO;
import com.placementhub.dsa.AdvancedDSA;
import com.placementhub.model.Job;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class JobAPI {

    private final JobDAO jobDAO = new JobDAO();

    public void registerRoutes(HttpServer server) {

        var jobsContext = server.createContext(
                "/api/jobs",
                this::handleJobs
        );

        jobsContext.getFilters().add(
                new CorsFilter()
        );

        var searchContext = server.createContext(
                "/api/jobs/search",
                this::searchJobs
        );

        searchContext.getFilters().add(
                new CorsFilter()
        );
    }

    // =====================================================
    // GET ALL JOBS
    // =====================================================

    private void handleJobs(
            HttpExchange exchange)
            throws IOException {

        if (!exchange.getRequestMethod()
                .equalsIgnoreCase("GET")) {

            send(
                    exchange,
                    405,
                    "{\"error\":\"GET required\"}"
            );

            return;
        }

        List<Job> jobs =
                jobDAO.getAllJobs();

        send(
                exchange,
                200,
                jobsToJson(jobs)
        );
    }

    // =====================================================
    // SEARCH JOBS
    // =====================================================

    private void searchJobs(
            HttpExchange exchange)
            throws IOException {

        if (!exchange.getRequestMethod()
                .equalsIgnoreCase("GET")) {

            send(
                    exchange,
                    405,
                    "{\"error\":\"GET required\"}"
            );

            return;
        }

        String query =
                exchange.getRequestURI()
                        .getRawQuery();

        String keyword =
                getQueryParameter(
                        query,
                        "keyword"
                );

        String algorithm =
                getQueryParameter(
                        query,
                        "algorithm"
                );

        if (keyword == null) {
            keyword = "";
        }

        if (algorithm == null) {
            algorithm = "fuzzy";
        }

        keyword = keyword.trim();

        List<Job> jobs =
                jobDAO.getAllJobs();

        List<Job> results =
                new ArrayList<>();

        // Empty search returns all jobs
        if (keyword.isEmpty()) {

            send(
                    exchange,
                    200,
                    jobsToJson(jobs)
            );

            return;
        }

        for (Job job : jobs) {

            String role =
                    safe(job.getJobRole());

            String skills =
                    safe(job.getRequiredSkills());

            String description =
                    safe(job.getJobDescription());

            boolean found = false;

            switch (
                    algorithm.toLowerCase()
            ) {

                case "kmp":

                    found =
                            AdvancedDSA.kmpSearch(
                                    role,
                                    keyword
                            )
                            ||
                            AdvancedDSA.kmpSearch(
                                    skills,
                                    keyword
                            )
                            ||
                            AdvancedDSA.kmpSearch(
                                    description,
                                    keyword
                            );

                    break;

                case "rabin":

                    found =
                            AdvancedDSA.rabinKarp(
                                    role,
                                    keyword
                            )
                            ||
                            AdvancedDSA.rabinKarp(
                                    skills,
                                    keyword
                            )
                            ||
                            AdvancedDSA.rabinKarp(
                                    description,
                                    keyword
                            );

                    break;

                case "fuzzy":

                    found =
                            AdvancedDSA.fuzzyMatch(
                                    keyword,
                                    role
                            )
                            ||
                            AdvancedDSA.fuzzyMatch(
                                    keyword,
                                    skills
                            )
                            ||
                            AdvancedDSA.fuzzyMatch(
                                    keyword,
                                    description
                            );

                    break;

                default:

                    found =
                            role.toLowerCase()
                                    .contains(
                                            keyword.toLowerCase()
                                    )
                            ||
                            skills.toLowerCase()
                                    .contains(
                                            keyword.toLowerCase()
                                    )
                            ||
                            description.toLowerCase()
                                    .contains(
                                            keyword.toLowerCase()
                                    );
            }

            if (found) {
                results.add(job);
            }
        }

        send(
                exchange,
                200,
                jobsToJson(results)
        );
    }

    // =====================================================
    // CONVERT JOBS TO JSON
    // =====================================================

    private String jobsToJson(
            List<Job> jobs) {

        StringBuilder json =
                new StringBuilder("[");

        for (int i = 0;
             i < jobs.size();
             i++) {

            Job job = jobs.get(i);

            json.append("{")

                    .append("\"jobId\":")
                    .append(job.getJobId())
                    .append(",")

                    .append("\"companyId\":")
                    .append(job.getCompanyId())
                    .append(",")

                    .append("\"jobRole\":\"")
                    .append(
                            escape(
                                    job.getJobRole()
                            )
                    )
                    .append("\",")

                    .append("\"packageLpa\":")
                    .append(job.getPackageLpa())
                    .append(",")

                    .append("\"minCgpa\":")
                    .append(job.getMinCgpa())
                    .append(",")

                    .append("\"allowedBranches\":\"")
                    .append(
                            escape(
                                    job.getAllowedBranches()
                            )
                    )
                    .append("\",")

                    .append("\"requiredSkills\":\"")
                    .append(
                            escape(
                                    job.getRequiredSkills()
                            )
                    )
                    .append("\",")

                    .append("\"maxBacklogs\":")
                    .append(job.getMaxBacklogs())
                    .append(",")

                    .append("\"driveDate\":\"")
                    .append(
                            escape(
                                    String.valueOf(
                                            job.getDriveDate()
                                    )
                            )
                    )
                    .append("\",")

                    .append("\"jobDescription\":\"")
                    .append(
                            escape(
                                    job.getJobDescription()
                            )
                    )
                    .append("\"")

                    .append("}");

            if (i < jobs.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        return json.toString();
    }

    // =====================================================
    // QUERY PARAMETER
    // =====================================================

    private String getQueryParameter(
            String query,
            String name) {

        if (query == null) {
            return null;
        }

        String[] parameters =
                query.split("&");

        for (String parameter :
                parameters) {

            String[] pair =
                    parameter.split("=", 2);

            if (
                    pair.length == 2
                    && pair[0].equals(name)
            ) {

                return URLDecoder.decode(
                        pair[1],
                        StandardCharsets.UTF_8
                );
            }
        }

        return null;
    }

    private String safe(String value) {

        return value == null
                ? ""
                : value;
    }

    private String escape(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }

    // =====================================================
    // SEND RESPONSE
    // =====================================================

    private void send(
            HttpExchange exchange,
            int status,
            String response)
            throws IOException {

        exchange.getResponseHeaders().set(
                "Content-Type",
                "application/json"
        );

        byte[] data =
                response.getBytes(
                        StandardCharsets.UTF_8
                );

        exchange.sendResponseHeaders(
                status,
                data.length
        );

        try (
                OutputStream output =
                        exchange.getResponseBody()
        ) {

            output.write(data);
        }
    }
}