package com.placementhub.service;

import com.placementhub.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminService {

    public void viewStudents() {
        displayTable(
                "SELECT * FROM students",
                "STUDENTS"
        );
    }

    public void viewCompanies() {
        displayTable(
                "SELECT * FROM companies",
                "COMPANIES"
        );
    }

    public void viewJobs() {
        displayTable(
                "SELECT * FROM jobs",
                "JOBS"
        );
    }

    public void viewApplications() {
        displayTable(
                "SELECT * FROM applications",
                "APPLICATIONS"
        );
    }

    public boolean updateApplicationStatus(
            int applicationId,
            String status) {

        String sql = """
                UPDATE applications
                SET status = ?
                WHERE application_id = ?
                """;

        try (Connection con =
                     DBConnection.getConnection();
             PreparedStatement ps =
                     con.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, applicationId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    private void displayTable(
            String sql,
            String title) {

        try (Connection con =
                     DBConnection.getConnection();
             PreparedStatement ps =
                     con.prepareStatement(sql);
             ResultSet rs =
                     ps.executeQuery()) {

            System.out.println();
            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "              " + title
            );

            System.out.println(
                    "========================================"
            );

            int columns =
                    rs.getMetaData()
                            .getColumnCount();

            while (rs.next()) {

                for (int i = 1;
                     i <= columns;
                     i++) {

                    System.out.print(
                            rs.getMetaData()
                              .getColumnName(i)
                            + " = "
                            + rs.getString(i)
                            + " | "
                    );
                }

                System.out.println();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}