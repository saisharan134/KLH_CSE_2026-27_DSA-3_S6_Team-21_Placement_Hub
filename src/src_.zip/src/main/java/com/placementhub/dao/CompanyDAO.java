package com.placementhub.dao;

import com.placementhub.DBConnection;
import com.placementhub.model.Company;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CompanyDAO {

    // =====================================================
    // GET ALL COMPANIES
    // =====================================================

    public List<Company> getAllCompanies() {

        List<Company> companies =
                new ArrayList<>();

        String sql =
                "SELECT * FROM companies";

        try (
                Connection con =
                        DBConnection.getConnection();

                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            while (rs.next()) {

                Company company =
                        new Company();

                company.setCompanyId(
                        rs.getInt("company_id")
                );

                company.setCompanyName(
                        rs.getString("company_name")
                );

                company.setLocation(
                        rs.getString("location")
                );

                company.setWebsite(
                        rs.getString("website")
                );

                company.setDescription(
                        rs.getString("description")
                );

                companies.add(company);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Company retrieval error: "
                            + e.getMessage()
            );
        }

        return companies;
    }


    // =====================================================
    // GET COMPANY BY ID
    // =====================================================

    public Company getCompanyById(
            int companyId) {

        String sql = """
                SELECT *
                FROM companies
                WHERE company_id = ?
                """;

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, companyId);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                Company company =
                        new Company();

                company.setCompanyId(
                        rs.getInt("company_id")
                );

                company.setCompanyName(
                        rs.getString("company_name")
                );

                company.setLocation(
                        rs.getString("location")
                );

                company.setWebsite(
                        rs.getString("website")
                );

                company.setDescription(
                        rs.getString("description")
                );

                return company;
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return null;
    }


    // =====================================================
    // ADD COMPANY
    // =====================================================

    public boolean addCompany(
            Company company) {

        String sql = """
                INSERT INTO companies
                (
                    company_name,
                    location,
                    website,
                    description
                )
                VALUES (?, ?, ?, ?)
                """;

        try (
                Connection con =
                        DBConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setString(
                    1,
                    company.getCompanyName()
            );

            ps.setString(
                    2,
                    company.getLocation()
            );

            ps.setString(
                    3,
                    company.getWebsite()
            );

            ps.setString(
                    4,
                    company.getDescription()
            );

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }
}