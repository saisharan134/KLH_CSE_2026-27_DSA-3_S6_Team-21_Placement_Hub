package com.placementhub.dao;

import com.placementhub.DBConnection;
import com.placementhub.model.Job;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JobDAO {

    public List<Job> getAllJobs() {

        List<Job> jobs = new ArrayList<>();

        String sql = "SELECT * FROM jobs";

        try (
                Connection con = DBConnection.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(sql)
        ) {

            while (rs.next()) {

                Job job = new Job();

                job.setJobId(
                        rs.getInt("job_id")
                );

                job.setCompanyId(
                        rs.getInt("company_id")
                );

                job.setJobRole(
                        rs.getString("job_role")
                );

                job.setPackageLpa(
                        rs.getDouble("package_lpa")
                );

                job.setMinCgpa(
                        rs.getDouble("min_cgpa")
                );

                job.setAllowedBranches(
                        rs.getString("allowed_branches")
                );

                job.setRequiredSkills(
                        rs.getString("required_skills")
                );

                job.setMaxBacklogs(
                        rs.getInt("max_backlogs")
                );

                java.sql.Date driveDate =
                        rs.getDate("drive_date");

                if (driveDate != null) {

                    job.setDriveDate(
                            driveDate.toLocalDate()
                    );

                } else {

                    job.setDriveDate(null);
                }

                job.setJobDescription(
                        rs.getString("job_description")
                );

                jobs.add(job);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return jobs;
    }
}