package com.placementhub.dao;

import com.placementhub.DBConnection;
import com.placementhub.model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentDAO {

    // =====================================================
    // REGISTER STUDENT
    // =====================================================

    public boolean register(Student student) {

        String sql = """
                INSERT INTO students
                (
                    name,
                    email,
                    password,
                    phone,
                    branch,
                    cgpa,
                    backlogs,
                    skills,
                    graduation_year
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getPassword());
            ps.setString(4, student.getPhone());
            ps.setString(5, student.getBranch());
            ps.setDouble(6, student.getCgpa());
            ps.setInt(7, student.getBacklogs());
            ps.setString(8, student.getSkills());
            ps.setInt(9, student.getGraduationYear());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Student registration error: "
                            + e.getMessage()
            );

            return false;
        }
    }


    // =====================================================
    // LOGIN STUDENT
    // =====================================================

    public Student login(
            String email,
            String password) {

        String sql = """
                SELECT
                    student_id,
                    name,
                    email,
                    password,
                    phone,
                    branch,
                    cgpa,
                    backlogs,
                    skills,
                    graduation_year
                FROM students
                WHERE email = ?
                AND password = ?
                """;

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Student student = new Student();

                student.setStudentId(
                        rs.getInt("student_id")
                );

                student.setName(
                        rs.getString("name")
                );

                student.setEmail(
                        rs.getString("email")
                );

                student.setPassword(
                        rs.getString("password")
                );

                student.setPhone(
                        rs.getString("phone")
                );

                student.setBranch(
                        rs.getString("branch")
                );

                student.setCgpa(
                        rs.getDouble("cgpa")
                );

                student.setBacklogs(
                        rs.getInt("backlogs")
                );

                student.setSkills(
                        rs.getString("skills")
                );

                student.setGraduationYear(
                        rs.getInt("graduation_year")
                );

                return student;
            }

        } catch (SQLException e) {

            System.out.println(
                    "Student login error: "
                            + e.getMessage()
            );
        }

        return null;
    }


    // =====================================================
    // FIND STUDENT BY ID
    // =====================================================

    public Student getStudentById(
            int studentId) {

        String sql = """
                SELECT *
                FROM students
                WHERE student_id = ?
                """;

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, studentId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Student student = new Student();

                student.setStudentId(
                        rs.getInt("student_id")
                );

                student.setName(
                        rs.getString("name")
                );

                student.setEmail(
                        rs.getString("email")
                );

                student.setPassword(
                        rs.getString("password")
                );

                student.setPhone(
                        rs.getString("phone")
                );

                student.setBranch(
                        rs.getString("branch")
                );

                student.setCgpa(
                        rs.getDouble("cgpa")
                );

                student.setBacklogs(
                        rs.getInt("backlogs")
                );

                student.setSkills(
                        rs.getString("skills")
                );

                student.setGraduationYear(
                        rs.getInt("graduation_year")
                );

                return student;
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return null;
    }
}