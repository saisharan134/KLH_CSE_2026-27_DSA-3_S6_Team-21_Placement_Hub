package com.placementhub.dao;

import com.placementhub.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ApplicationDAO {

    public boolean applyForJob(
            int studentId,
            int jobId) {

        String checkSql = """
                SELECT application_id
                FROM applications
                WHERE student_id = ?
                AND job_id = ?
                """;

        String insertSql = """
                INSERT INTO applications
                (student_id, job_id,
                 application_date, status)
                VALUES (?, ?, CURDATE(), 'Applied')
                """;

        try (Connection con =
                     DBConnection.getConnection()) {

            try (PreparedStatement check =
                         con.prepareStatement(checkSql)) {

                check.setInt(1, studentId);
                check.setInt(2, jobId);

                ResultSet rs =
                        check.executeQuery();

                if (rs.next()) {
                    System.out.println(
                            "Already applied for this job."
                    );
                    return false;
                }
            }

            try (PreparedStatement ps =
                         con.prepareStatement(insertSql)) {

                ps.setInt(1, studentId);
                ps.setInt(2, jobId);

                return ps.executeUpdate() > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public void viewStudentApplications(
            int studentId) {

        String sql = """
                SELECT a.application_id,
                       a.job_id,
                       a.application_date,
                       a.status,
                       j.job_role
                FROM applications a
                JOIN jobs j
                ON a.job_id = j.job_id
                WHERE a.student_id = ?
                """;

        try (Connection con =
                     DBConnection.getConnection();
             PreparedStatement ps =
                     con.prepareStatement(sql)) {

            ps.setInt(1, studentId);

            ResultSet rs =
                    ps.executeQuery();

            System.out.println();
            System.out.println(
                    "========== MY APPLICATIONS =========="
            );

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println(
                        "Application ID : "
                        + rs.getInt("application_id")
                );

                System.out.println(
                        "Job            : "
                        + rs.getString("job_role")
                );

                System.out.println(
                        "Date           : "
                        + rs.getDate("application_date")
                );

                System.out.println(
                        "Status         : "
                        + rs.getString("status")
                );

                System.out.println(
                        "------------------------------------"
                );
            }

            if (!found) {
                System.out.println(
                        "No applications found."
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public boolean updateStatus(
            int applicationId,
            String status) {

        String sql = """
                UPDATE applications
                SET status = ?
                WHERE application_id = ?
                """;

        try (Connection con =
                     DBConnection.getConnection();
             PreparedStatement ps =
                     con.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, applicationId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}