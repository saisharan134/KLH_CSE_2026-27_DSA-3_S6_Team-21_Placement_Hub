package com.placementhub;

import com.placementhub.api.ApplicationAPI;
import com.placementhub.api.CompanyAPI;
import com.placementhub.api.JobAPI;
import com.placementhub.api.StudentAPI;

import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;

public class WebServer {

    private static final int PORT = 8080;

    private HttpServer server;

    public void start()
            throws IOException {

        server =
                HttpServer.create(
                        new InetSocketAddress(
                                PORT
                        ),
                        0
                );


        // Student API
        StudentAPI studentAPI =
                new StudentAPI();

        studentAPI.registerRoutes(
                server
        );


        // Job API
        JobAPI jobAPI =
                new JobAPI();

        jobAPI.registerRoutes(
                server
        );


        // Company API
        CompanyAPI companyAPI =
                new CompanyAPI();

        companyAPI.registerRoutes(
                server
        );


        // Application API
        ApplicationAPI applicationAPI =
                new ApplicationAPI();

        applicationAPI.registerRoutes(
                server
        );


        server.start();


        System.out.println();
        System.out.println(
                "======================================"
        );
        System.out.println(
                "          PLACEMENT HUB"
        );
        System.out.println(
                "          DSA-3 WEB SERVER"
        );
        System.out.println(
                "======================================"
        );

        System.out.println(
                "Server running at:"
        );

        System.out.println(
                "http://localhost:" + PORT
        );

        System.out.println();

        System.out.println(
                "Available APIs:"
        );

        System.out.println(
                "POST /api/students/login"
        );

        System.out.println(
                "POST /api/students/register"
        );

        System.out.println(
                "GET  /api/jobs"
        );

        System.out.println(
                "GET  /api/jobs/search"
        );

        System.out.println(
                "GET  /api/companies"
        );

        System.out.println(
                "POST /api/applications"
        );

        System.out.println(
                "GET  /api/applications?studentId=1"
        );

        System.out.println();
    }


    public void stop() {

        if (server != null) {

            server.stop(0);

            System.out.println(
                    "Server stopped."
            );
        }
    }
}