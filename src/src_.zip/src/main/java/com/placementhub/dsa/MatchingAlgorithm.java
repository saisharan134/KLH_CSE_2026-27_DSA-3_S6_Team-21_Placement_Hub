package com.placementhub.dsa;

import com.placementhub.model.Job;
import com.placementhub.model.Student;

import java.util.HashMap;
import java.util.Map;

public class MatchingAlgorithm {

    public double calculateSkillMatch(
            Student student,
            Job job) {

        Map<String, Boolean> studentSkills =
                new HashMap<>();

        String skills = student.getSkills();

        if (skills == null || skills.isBlank()) {
            return 0;
        }

        for (String skill : skills.split(",")) {

            studentSkills.put(
                    skill.trim().toLowerCase(),
                    true
            );
        }

        String required =
                job.getRequiredSkills();

        if (required == null || required.isBlank()) {
            return 0;
        }

        String[] requiredSkills =
                required.split(",");

        int matched = 0;

        for (String skill : requiredSkills) {

            if (studentSkills.containsKey(
                    skill.trim().toLowerCase())) {

                matched++;
            }
        }

        return ((double) matched /
                requiredSkills.length) * 100;
    }


    public double calculateOverallMatch(
            Student student,
            Job job) {

        double skillScore =
                calculateSkillMatch(student, job);

        double cgpaScore =
                Math.min(
                        student.getCgpa() * 10,
                        100
                );

        return
                (skillScore * 0.60)
                +
                (cgpaScore * 0.40);
    }
}