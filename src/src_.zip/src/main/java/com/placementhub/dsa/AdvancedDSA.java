package com.placementhub.dsa;

public class AdvancedDSA {

    // =====================================================
    // 1. KMP STRING SEARCH
    // =====================================================

    public static boolean kmpSearch(
            String text,
            String pattern) {

        if (text == null || pattern == null) {
            return false;
        }

        if (pattern.isEmpty()) {
            return true;
        }

        text = text.toLowerCase();
        pattern = pattern.toLowerCase();

        int[] lps =
                buildLPS(pattern);

        int i = 0;
        int j = 0;

        while (i < text.length()) {

            if (text.charAt(i)
                    == pattern.charAt(j)) {

                i++;
                j++;

                if (j == pattern.length()) {
                    return true;
                }

            } else {

                if (j != 0) {

                    j = lps[j - 1];

                } else {

                    i++;
                }
            }
        }

        return false;
    }


    // =====================================================
    // LPS ARRAY FOR KMP
    // =====================================================

    private static int[] buildLPS(
            String pattern) {

        int[] lps =
                new int[pattern.length()];

        int length = 0;

        int i = 1;

        while (i < pattern.length()) {

            if (pattern.charAt(i)
                    == pattern.charAt(length)) {

                length++;

                lps[i] = length;

                i++;

            } else {

                if (length != 0) {

                    length =
                            lps[length - 1];

                } else {

                    lps[i] = 0;

                    i++;
                }
            }
        }

        return lps;
    }


    // =====================================================
    // 2. RABIN-KARP STRING SEARCH
    // =====================================================

    public static boolean rabinKarp(
            String text,
            String pattern) {

        if (text == null || pattern == null) {
            return false;
        }

        if (pattern.isEmpty()) {
            return true;
        }

        text = text.toLowerCase();
        pattern = pattern.toLowerCase();

        int n = text.length();
        int m = pattern.length();

        if (m > n) {
            return false;
        }

        final int BASE = 256;
        final int PRIME = 101;

        long patternHash = 0;
        long textHash = 0;

        long h = 1;

        for (int i = 0; i < m - 1; i++) {

            h =
                    (h * BASE)
                    % PRIME;
        }

        for (int i = 0; i < m; i++) {

            patternHash =
                    (
                        BASE * patternHash
                        + pattern.charAt(i)
                    ) % PRIME;

            textHash =
                    (
                        BASE * textHash
                        + text.charAt(i)
                    ) % PRIME;
        }

        for (int i = 0;
             i <= n - m;
             i++) {

            if (patternHash == textHash) {

                boolean match = true;

                for (int j = 0;
                     j < m;
                     j++) {

                    if (
                        text.charAt(i + j)
                        != pattern.charAt(j)
                    ) {

                        match = false;
                        break;
                    }
                }

                if (match) {
                    return true;
                }
            }

            if (i < n - m) {

                textHash =
                        (
                            BASE *
                            (
                                textHash
                                - text.charAt(i) * h
                            )
                            + text.charAt(i + m)
                        ) % PRIME;

                if (textHash < 0) {
                    textHash += PRIME;
                }
            }
        }

        return false;
    }


    // =====================================================
    // 3. EDIT DISTANCE
    // =====================================================

    public static int editDistance(
            String a,
            String b) {

        if (a == null) {
            return b == null ? 0 : b.length();
        }

        if (b == null) {
            return a.length();
        }

        a = a.toLowerCase();
        b = b.toLowerCase();

        int[][] dp =
                new int[
                        a.length() + 1
                ][
                        b.length() + 1
                ];


        for (int i = 0;
             i <= a.length();
             i++) {

            dp[i][0] = i;
        }


        for (int j = 0;
             j <= b.length();
             j++) {

            dp[0][j] = j;
        }


        for (int i = 1;
             i <= a.length();
             i++) {

            for (int j = 1;
                 j <= b.length();
                 j++) {

                int cost =
                        a.charAt(i - 1)
                        == b.charAt(j - 1)
                        ? 0
                        : 1;


                dp[i][j] =
                        Math.min(

                            Math.min(

                                dp[i - 1][j] + 1,

                                dp[i][j - 1] + 1
                            ),

                            dp[i - 1][j - 1]
                            + cost
                        );
            }
        }

        return dp[
                a.length()
        ][
                b.length()
        ];
    }


    // =====================================================
    // 4. FUZZY SIMILARITY
    // =====================================================

    public static double similarity(
            String a,
            String b) {

        if (a == null || b == null) {
            return 0;
        }

        if (a.isEmpty() && b.isEmpty()) {
            return 100;
        }

        int distance =
                editDistance(a, b);

        int maxLength =
                Math.max(
                        a.length(),
                        b.length()
                );

        if (maxLength == 0) {
            return 100;
        }

        return (
                1.0
                - (
                    (double) distance
                    / maxLength
                )
        ) * 100;
    }


    // =====================================================
    // 5. FUZZY MATCH
    // =====================================================

    public static boolean fuzzyMatch(
            String query,
            String text) {

        if (query == null || text == null) {
            return false;
        }

        query = query.trim();

        text = text.trim();

        if (query.isEmpty()) {
            return true;
        }

        // Exact substring match
        if (
            text.toLowerCase()
                .contains(
                    query.toLowerCase()
                )
        ) {
            return true;
        }

        // Compare with individual words
        String[] words =
                text.split("[,\\s]+");

        for (String word : words) {

            if (
                similarity(
                    query,
                    word
                ) >= 65
            ) {
                return true;
            }
        }

        return false;
    }


    // =====================================================
    // 6. JOB MATCH SCORE
    // =====================================================

    public static double calculateMatchScore(
            String studentSkills,
            String requiredSkills,
            double studentCgpa,
            double minimumCgpa) {

        double skillScore =
                calculateSkillScore(
                        studentSkills,
                        requiredSkills
                );


        double cgpaScore;


        if (studentCgpa >= minimumCgpa) {

            cgpaScore = 100;

        } else {

            cgpaScore = 0;
        }


        // Skills = 70%
        // CGPA = 30%

        return (
                skillScore * 0.70
        )
        +
        (
                cgpaScore * 0.30
        );
    }


    // =====================================================
    // 7. SKILL MATCHING
    // =====================================================

    public static double calculateSkillScore(
            String studentSkills,
            String requiredSkills) {

        if (
            studentSkills == null
            || requiredSkills == null
            || studentSkills.isBlank()
            || requiredSkills.isBlank()
        ) {
            return 0;
        }


        String[] student =
                studentSkills
                    .toLowerCase()
                    .split(",");


        String[] required =
                requiredSkills
                    .toLowerCase()
                    .split(",");


        int matched = 0;


        for (String req :
                required) {

            req = req.trim();

            if (req.isEmpty()) {
                continue;
            }


            for (String skill :
                    student) {

                skill = skill.trim();

                if (
                    fuzzyMatch(
                        skill,
                        req
                    )
                ) {

                    matched++;

                    break;
                }
            }
        }


        if (required.length == 0) {
            return 0;
        }


        return (
                (double) matched
                / required.length
        ) * 100;
    }


    // =====================================================
    // 8. PRIME CHECK
    // =====================================================

    public static boolean isPrime(
            int number) {

        if (number <= 1) {
            return false;
        }

        if (number == 2) {
            return true;
        }

        if (number % 2 == 0) {
            return false;
        }

        for (
            int i = 3;
            i * i <= number;
            i += 2
        ) {

            if (number % i == 0) {
                return false;
            }
        }

        return true;
    }


    // =====================================================
    // 9. DEMONSTRATION
    // =====================================================

    public static void main(
            String[] args) {

        System.out.println(
                "===== Advanced DSA Demo ====="
        );


        // KMP
        System.out.println(
                "KMP: "
                +
                kmpSearch(
                        "Java Developer",
                        "Developer"
                )
        );


        // Rabin-Karp
        System.out.println(
                "Rabin-Karp: "
                +
                rabinKarp(
                        "Python Developer",
                        "Python"
                )
        );


        // Edit Distance
        System.out.println(
                "Edit Distance: "
                +
                editDistance(
                        "Jvaa",
                        "Java"
                )
        );


        // Similarity
        System.out.println(
                "Similarity: "
                +
                similarity(
                        "Jvaa",
                        "Java"
                )
        );


        // Fuzzy Search
        System.out.println(
                "Fuzzy Match: "
                +
                fuzzyMatch(
                        "Jvaa",
                        "Java Developer"
                )
        );


        // Skill Matching
        System.out.println(
                "Skill Score: "
                +
                calculateSkillScore(
                        "Java,SQL,DSA,Python",
                        "Java,SQL,DSA"
                )
        );


        // Job Match
        System.out.println(
                "Job Match Score: "
                +
                calculateMatchScore(
                        "Java,SQL,DSA",
                        "Java,SQL,DSA",
                        8.5,
                        7.0
                )
        );
    }
}