package com.placementhub.dsa;

import com.placementhub.model.Job;

import java.util.ArrayList;
import java.util.List;

public class JobSort {

    public List<Job> sortByPackage(
            List<Job> jobs) {

        List<Job> result =
                new ArrayList<>(jobs);

        // Bubble Sort
        for (int i = 0;
             i < result.size() - 1;
             i++) {

            for (int j = 0;
                 j < result.size() - i - 1;
                 j++) {

                if (result.get(j).getPackageLpa()
                        < result.get(j + 1)
                        .getPackageLpa()) {

                    Job temp = result.get(j);

                    result.set(
                            j,
                            result.get(j + 1)
                    );

                    result.set(
                            j + 1,
                            temp
                    );
                }
            }
        }

        return result;
    }
}