package com.placementhub.dsa;

import com.placementhub.model.Job;

import java.util.ArrayList;
import java.util.List;

public class FuzzySearch {

    // Returns similarity percentage between two strings
    public double similarity(String text1, String text2) {

        text1 = text1.toLowerCase().trim();
        text2 = text2.toLowerCase().trim();

        if (text1.equals(text2)) {
            return 100.0;
        }

        int distance = levenshteinDistance(text1, text2);

        int maxLength =
                Math.max(text1.length(), text2.length());

        if (maxLength == 0) {
            return 100.0;
        }

        return (1.0 -
                ((double) distance / maxLength))
                * 100.0;
    }


    // Levenshtein Distance
    private int levenshteinDistance(
            String text1,
            String text2) {

        int[][] dp =
                new int[text1.length() + 1]
                        [text2.length() + 1];

        for (int i = 0; i <= text1.length(); i++) {
            dp[i][0] = i;
        }

        for (int j = 0; j <= text2.length(); j++) {
            dp[0][j] = j;
        }

        for (int i = 1;
             i <= text1.length();
             i++) {

            for (int j = 1;
                 j <= text2.length();
                 j++) {

                int cost =
                        text1.charAt(i - 1)
                        ==
                        text2.charAt(j - 1)
                        ? 0
                        : 1;

                dp[i][j] =
                        Math.min(
                                Math.min(
                                        dp[i - 1][j] + 1,
                                        dp[i][j - 1] + 1
                                ),
                                dp[i - 1][j - 1]
                                        + cost
                        );
            }
        }

        return dp[text1.length()]
                  [text2.length()];
    }


    // Search jobs using fuzzy matching
    public List<Job> fuzzySearch(
            List<Job> jobs,
            String keyword,
            double threshold) {

        List<Job> results =
                new ArrayList<>();

        for (Job job : jobs) {

            double score =
                    similarity(
                            keyword,
                            job.getJobRole()
                    );

            if (score >= threshold) {
                results.add(job);
            }
        }

        return results;
    }
}