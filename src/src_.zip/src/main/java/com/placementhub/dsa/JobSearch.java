package com.placementhub.dsa;

import com.placementhub.model.Job;

import java.util.ArrayList;
import java.util.List;

public class JobSearch {

    public List<Job> search(
            List<Job> jobs,
            String keyword) {

        List<Job> result =
                new ArrayList<>();

        for (Job job : jobs) {

            if (job.getJobRole()
                    .toLowerCase()
                    .contains(
                            keyword.toLowerCase()
                    )) {

                result.add(job);
            }
        }

        return result;
    }
}